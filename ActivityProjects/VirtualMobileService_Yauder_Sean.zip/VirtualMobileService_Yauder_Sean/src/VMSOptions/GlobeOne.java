package VMSOptions;

public class GlobeOne {
    public static void GlobeOneProc() {
        
            Helper.clearTerminal();
            System.out.println("Thank you! You will get a response via text shortly\n");
            Helper.delay(3000);
            Helper.returning();
            
    }
}
